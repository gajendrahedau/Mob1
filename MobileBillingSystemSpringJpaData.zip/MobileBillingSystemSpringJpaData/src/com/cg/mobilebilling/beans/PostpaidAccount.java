package com.cg.mobilebilling.beans;
import java.util.HashMap;

import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class PostpaidAccount {
	private long mobileNo;
	@OneToOne
	private Plan plan;
	@ManyToOne
	private Customer customer;
	
	@OneToMany(mappedBy="postpaidAccount")
	private  Map<Integer, Bill> bills;
	public PostpaidAccount() {}
	public PostpaidAccount(long mobileNo, Plan plan, Map<Integer, Bill> bills) {
		super();
		this.mobileNo = mobileNo;
		this.plan = plan;
		this.bills = bills;
	}
	
	public PostpaidAccount(Plan plan, Customer customer) {
		super();
		this.plan = plan;
		this.customer = customer;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Map<Integer, Bill> getBills() {
		return bills;
	}
	public void setBills(Map<Integer, Bill> bills) {
		this.bills = bills;
	}
	@Override
	public String toString() {
		return "PostpaidAccount [mobileNo=" + mobileNo + ", plan=" + plan + ", bills=" + bills + "]";
	}
	
}