package com.cg.mobilebilling.controllers;
import java.util.List;

import javax.validation.Valid;

import org.jboss.logging.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping("/acceptCustomerDetails")
	public ModelAndView acceptCustomerDetails(@Valid @ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors()) 
			return new ModelAndView("acceptCustomerDetailsPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("newAccepCustomerDetailsPage","customer",customer);
	}
	@RequestMapping("/openPostpaidMobileAccount")
	public ModelAndView openPostpaidMobileAccount(@RequestParam("customerID") int customerID,@RequestParam("planID") int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		long mobileNo=billingServices.openPostpaidMobileAccount(customerID, planID);
		PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("newOpenPostpaidMobileAccountPage","postpaidAccount",postpaidAccount);	
	}
	@RequestMapping("/getCustomerDetails")
	public ModelAndView getCustomerDetails(@RequestParam("customerID") int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=billingServices.getCustomerDetails(customerID);
		return new ModelAndView("newGetCustomerDetailsPage","customer",customer);	
	}
	@RequestMapping("/getPostPaidAccountDetails")
	public ModelAndView getPostPaidAccountDetailsPage(@RequestParam("customerID") int customerID,@RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException  {
		mobileNo=mobileNo-9852600400l;
		PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("newGetPostPaidAccountDetailsPage","postpaidAccount",postpaidAccount);	
	}
	@RequestMapping("/changePlane")
	public ModelAndView changePlane(@RequestParam("customerID") int customerID,@RequestParam("mobileNo") long mobileNo,@RequestParam("planID") int planID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		mobileNo=mobileNo-9852600400l;
		boolean b=billingServices.changePlan(customerID, mobileNo, planID);
		System.out.println(b);
		PostpaidAccount postPaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("newChangePlanPage","postPaidAccount",postPaidAccount);	
	}
	@RequestMapping("/getCustomerAllPostpaidAccountsDetails")
	public ModelAndView getCustomerAllPostpaidAccountsDetails(@RequestParam("customerID") int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		List<PostpaidAccount>lists=billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ModelAndView("newGetCustomerAllPostpaidAccountsDetailsPage","lists",lists);	
	}
	@RequestMapping("closeCustomerPostPaidAccount")
	public ModelAndView closeCustomerPostPaidAccountPage(@RequestParam("customerID") int customerID,@RequestParam("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException{
		billingServices.closeCustomerPostPaidAccount(customerID, (mobileNo-9852600400l));
		String message="Customer with customer Id "+customerID+" and mobile number "+(mobileNo)+" has been closed.";
		return new ModelAndView("closeCustomerPostPaidAccountPage","message",message);
	}
	@RequestMapping("deleteCustomer")
	public ModelAndView deleteCustomerPage(@RequestParam("customerID") int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		billingServices.deleteCustomer(customerID);
		String message="Customer Account with customer Id "+customerID+" has been deleted.";
		return new ModelAndView("deleteCustomerPage","message",message);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
