package com.cg.mobilebilling.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
public class MainClass {
	public static void main(String[] args) throws CustomerDetailsNotFoundException, BillingServicesDownException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServices billingServices=(BillingServices) applicationContext.getBean("billingServices");
		billingServices.getCustomerDetails(1);
	}
}